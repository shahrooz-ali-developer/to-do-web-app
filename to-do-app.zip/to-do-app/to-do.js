//  alert('hello')
 document.addEventListener('DOMContentLoaded',()=>
{

    const inputtask =document.getElementById('input-task');
    const submittask = document.getElementById('add-task-btn');
    const listtask =document.getElementById('task-added');
    const emptyimage = document.querySelector('.empty-image');

    

    const addtask=(event)=>{
event.preventDefault();
        const tasktext =inputtask.value.trim();
        if(!tasktext)
        {
            return
        }


        

  const li = document.createElement('li');
li.innerHTML = `
  <span class="task-text">${tasktext}</span>
  <div class="buttoncontainer">
    <button class="del-button"><i class="fa-solid fa-trash"></i></button>
  </div>
`;

// del 
        li.querySelector('.del-button').
        addEventListener('click',()=>{
            li.remove();
            toggleremove_remveimg();
        })

listtask.appendChild(li);
inputtask.value = '';
toggleremove_remveimg();


    }
    submittask.addEventListener('click', addtask);
    inputtask.addEventListener('keypress', (e)=>{
        if(e.key ==='Enter'){
            addtask(e);
        }
    })

})

